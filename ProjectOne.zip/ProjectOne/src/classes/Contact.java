package classes;

public class Contact {

	private String ID;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	public Contact(String ID, String first, String last, String phone, String address) {
		if (ID == null || ID.length() > 10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		if (first == null || first.length() > 10) {
			throw new IllegalArgumentException("Invalid First Name");
		}
		if (last == null || last.length() > 10) {
			throw new IllegalArgumentException("Invalid Last Name");
		}
		if (phone == null || phone.length() != 10) {
			throw new IllegalArgumentException("Invalid Phone Number");
		}
		if (address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid Address");
		}
		this.ID = ID;
		this.firstName = first;
		this.lastName = last;
		this.phone = phone;
		this.address = address;
	}

	public String getID() {
		return ID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String first) {
		if (first == null || first.length() > 10) {
			throw new IllegalArgumentException("Invalid First Name");
		}
		this.firstName = first;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String last) {
		if (last == null || last.length() > 10) {
			throw new IllegalArgumentException("Invalid Last Name");
		}
		this.lastName = last;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		if (phone == null || phone.length() != 10) {
			throw new IllegalArgumentException("Invalid Phone Number");
		}
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		if (address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid Address");
		}
		this.address = address;
	}
	
	
}

package classes;

import java.util.ArrayList;

public class TaskService {
	private ArrayList<Task> tasks;
	
	public TaskService() {
		tasks = new ArrayList<Task>();
	}
	
	public void addTask(Task task) {	
		for(Task t : tasks) {
			if(t.getID().equals(task.getID())) {
				throw new IllegalArgumentException("Task with given ID already exists");
			}
		}
		tasks.add(task);
	}
	
	public void removeTask(String ID) {
		for(Task t : tasks) {
			if (t.getID().equals(ID)) {
				tasks.remove(t);
				return;
			}
		}
		throw new IllegalArgumentException("Task with ID not found");
	}
	
	public void updateTaskName(String ID, String name) {
		for(Task t : tasks) {
			if (t.getID().equals(ID)) {
				t.setName(name);
				return;
			}
		}
		throw new IllegalArgumentException("Task with ID not found");
	}
	
	public void updateTaskDescription(String ID, String description) {
		for(Task t : tasks) {
			if (t.getID().equals(ID)) {
				t.setDescription(description);
				return;
			}
		}
		throw new IllegalArgumentException("Task with ID not found");
	}
}

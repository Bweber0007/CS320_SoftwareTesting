package classes;

import java.util.ArrayList;

public class ContactService {

	private ArrayList<Contact> contacts;
	
	public ContactService() {
		contacts = new ArrayList<Contact>();
	}
	
	public void addContact(Contact contact) {	
		for(Contact c : contacts) {
			if(c.getID().equals(contact.getID())) {
				throw new IllegalArgumentException("Contact with given ID already exists");
			}
		}
		
		contacts.add(contact);
	}
	
	public void removeContact(String ID) {
		for(Contact contact : contacts) {
			if (contact.getID().equals(ID)) {
				contacts.remove(contact);
				return;
			}
		}
		throw new IllegalArgumentException("Contact with ID not found");
	}
	
	public void updateContactFirst(String ID, String first) {
		for(Contact contact : contacts) {
			if (contact.getID().equals(ID)) {
				contact.setFirstName(first);
				return;
			}
		}
		throw new IllegalArgumentException("Contact with ID not found");
	}
	
	public void updateContactLast(String ID, String last) {
		for(Contact contact : contacts) {
			if (contact.getID().equals(ID)) {
				contact.setLastName(last);
				return;
			}
		}
		throw new IllegalArgumentException("Contact with ID not found");
	}
	
	public void updateContactPhone(String ID, String phone) {
		for(Contact contact : contacts) {
			if (contact.getID().equals(ID)) {
				contact.setPhone(phone);
				return;
			}
		}
		throw new IllegalArgumentException("Contact with ID not found");
	}
	
	public void updateContactAddress(String ID, String address) {
		for(Contact contact : contacts) {
			if (contact.getID().equals(ID)) {
				contact.setAddress(address);
				return;
			}
		}
		throw new IllegalArgumentException("Contact with ID not found");
	}

}

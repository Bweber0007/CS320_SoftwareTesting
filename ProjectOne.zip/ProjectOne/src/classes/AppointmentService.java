package classes;

import java.util.ArrayList;

public class AppointmentService {

	private ArrayList<Appointment> appointments;
	
	public AppointmentService() {
		appointments = new ArrayList<Appointment>();
	}
	
	public void addAppointment(Appointment appt) {
		for(Appointment a : appointments) {
			if(appt.getID().equals(a.getID())) {
				throw new IllegalArgumentException("Appointment with ID already exists");
			}
		}
		appointments.add(appt);
	}
	
	public void deleteAppointment(String ID) {
		for(Appointment a : appointments) {
			if(a.getID().equals(ID)) {
				appointments.remove(a);
				return;
			}
		}
		throw new IllegalArgumentException("No appointment found");
	}
	
}

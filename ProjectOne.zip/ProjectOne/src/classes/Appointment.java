package classes;

import java.util.Date;

public class Appointment {
	private String ID;
	private Date date;
	private String description;
	
	public Appointment(String ID, Date date, String description) {
		if(ID == null || ID.length()>10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		setDescription(description);
		setDate(date);
		this.ID = ID;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		if(date == null || date.before(new Date())) {
			throw new IllegalArgumentException("Invalid Date");
		}
		this.date = date;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		if(description == null || description.length()>50) {
			throw new IllegalArgumentException("Invalid Description");
		}
		this.description = description;
	}

	public String getID() {
		return ID;
	}
	
		
}

package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import classes.Contact;

class ContactTest {

	@Test
	void testContactAssignsCorrectly() {
		Contact contact = new Contact("12345","first","last","3333333333","1234 address dr");
		assertTrue(contact.getID().equals("12345"));
		assertTrue(contact.getFirstName().equals("first"));
		assertTrue(contact.getLastName().equals("last"));
		assertTrue(contact.getPhone().equals("3333333333"));
		assertTrue(contact.getAddress().equals("1234 address dr"));
	}
	
	@Test
	void testContactThrowsExceptionsForNull() {
		assertThrows(IllegalArgumentException.class,() -> 
		{ new Contact(null,"123","123","1234567890","123"); }
		); 
		assertThrows(IllegalArgumentException.class,() -> 
		{ new Contact("123",null,"123","1234567890","123"); }
		); 
		assertThrows(IllegalArgumentException.class,() -> 
		{ new Contact("123","123",null,"1234567890","123"); }
		); 
		assertThrows(IllegalArgumentException.class,() -> 
		{ new Contact("123","123","123",null,"123"); }
		); 
		assertThrows(IllegalArgumentException.class,() -> 
		{ new Contact("123","123","123","1234567890",null); }
		); 
	}
	
	@Test
	void testContactThrowsExceptionsForLength() {
		assertThrows(IllegalArgumentException.class,() -> 
		{ new Contact("12345678910","123","123","1234567890","123"); }
		); 
		assertThrows(IllegalArgumentException.class,() -> 
		{ new Contact("123","12345678910","123","1234567890","123"); }
		); 
		assertThrows(IllegalArgumentException.class,() -> 
		{ new Contact("123","123","12345678910","1234567890","123"); }
		); 
		assertThrows(IllegalArgumentException.class,() -> 
		{ new Contact("123","123","123","12345678901","123"); }
		);
		assertThrows(IllegalArgumentException.class,() -> 
		{ new Contact("123","123","123","123456789","123"); }
		);
		assertThrows(IllegalArgumentException.class,() -> 
		{ new Contact("123","123","123","1234567890","1234567891234567891234567891234"); }
		); 
	}

		

}

package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import classes.Task;

class TaskTest {
	
	@Test
	void testTaskAssignsCorrectly() {
		Task t = new Task("123","234","345");
		assertTrue(t.getID().equals("123"));
		assertTrue(t.getName().equals("234"));
		assertTrue(t.getDescription().equals("345"));
	}
	
	@Test
	void testTaskThrowsExceptionsForNull() {
		assertThrows(IllegalArgumentException.class,() -> 
		{ new Task(null,"123","123"); }
		); 
		assertThrows(IllegalArgumentException.class,() -> 
		{ new Task("123",null,"123"); }
		); 
		assertThrows(IllegalArgumentException.class,() -> 
		{ new Task("123","123",null); }
		); 
	}
	
	@Test
	void testTaskThrowsExceptionsForLength() {
		assertThrows(IllegalArgumentException.class,() -> 
		{ new Task("12345678901","123","123"); }
		); 
		assertThrows(IllegalArgumentException.class,() -> 
		{ new Task("123","123456789012345678901","123"); }
		); 
		assertThrows(IllegalArgumentException.class,() -> 
		{ new Task("123","123","123456789012345678901234567890123456789012345678901"); }
		); 
	}

}

package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import classes.Contact;

import classes.ContactService;

class ContactServiceTest {
	
	public Contact contact1 = new Contact("123","123","123","1234567890","123");
	
	@Test
	void testAddContact() {
		ContactService cs = new ContactService();
		cs.addContact(contact1);
		assertThrows(IllegalArgumentException.class,() -> 
		{cs.addContact(contact1); }
		); 
	}
	
	@Test
	void testRemoveContact() {
		ContactService cs = new ContactService();
		cs.addContact(contact1);
		assertThrows(IllegalArgumentException.class,() -> 
		{cs.removeContact("111"); }
		); 
		cs.removeContact("123");
		assertThrows(IllegalArgumentException.class,() -> 
		{cs.removeContact("123"); }
		); 
	}
	
	@Test
	void testUpdateContactFirstName() {
		contact1 = new Contact("123","123","123","1234567890","123");
		ContactService cs = new ContactService();
		cs.addContact(contact1);
		assertThrows(IllegalArgumentException.class,() -> 
		{cs.updateContactFirst("111","123"); }
		); 
		cs.updateContactFirst("123", "first");
		assertTrue(contact1.getFirstName().equals("first"));
	}

	@Test
	void testUpdateContactLastName() {
		contact1 = new Contact("123","123","123","1234567890","123");
		ContactService cs = new ContactService();
		cs.addContact(contact1);
		assertThrows(IllegalArgumentException.class,() -> 
		{cs.updateContactLast("111","123"); }
		); 
		cs.updateContactLast("123", "last");
		assertTrue(contact1.getLastName().equals("last"));
	}
	
	@Test
	void testUpdateContactPhone() {
		contact1 = new Contact("123","123","123","1234567890","123");
		ContactService cs = new ContactService();
		cs.addContact(contact1);
		assertThrows(IllegalArgumentException.class,() -> 
		{cs.updateContactPhone("111","1234567890"); }
		); 
		cs.updateContactPhone("123", "2345678901");
		assertTrue(contact1.getPhone().equals("2345678901"));
	}
	
	@Test
	void testUpdateContactAddress() {
		contact1 = new Contact("123","123","123","1234567890","123");
		ContactService cs = new ContactService();
		cs.addContact(contact1);
		assertThrows(IllegalArgumentException.class,() -> 
		{cs.updateContactAddress("111","123"); }
		); 
		cs.updateContactAddress("123", "234");
		assertTrue(contact1.getAddress().equals("234"));
	}
}

package tests;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import classes.Task;
import classes.TaskService;

public class TaskServiceTest {
	
	public Task t = new Task("1","2","3");
	
	@Test
	void testAddTask() {
		TaskService ts = new TaskService();
		ts.addTask(t);
		assertThrows(IllegalArgumentException.class,() -> 
		{ts.addTask(t); }
		); 
	}
	
	@Test
	void testRemoveContact() {
		TaskService ts = new TaskService();
		ts.addTask(t);
		ts.removeTask(t.getID());
		assertThrows(IllegalArgumentException.class,() -> 
		{ts.removeTask(t.getID()); }
		); 
	}
	
	@Test
	void testUpdateTaskName() {
		TaskService ts = new TaskService();
		ts.addTask(t);
		assertThrows(IllegalArgumentException.class,() -> 
		{ts.updateTaskName("0","3"); }
		); 
		ts.updateTaskName(t.getID(), "5");
		assertTrue(t.getName().equals("5"));
	}
	
	@Test
	void testUpdateTaskDescription() {
		TaskService ts = new TaskService();
		ts.addTask(t);
		assertThrows(IllegalArgumentException.class,() -> 
		{ts.updateTaskDescription("0","3"); }
		); 
		ts.updateTaskDescription(t.getID(), "5");
		assertTrue(t.getDescription().equals("5"));
	}
	
}

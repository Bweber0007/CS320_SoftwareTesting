package tests;

import java.util.Date;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import classes.Appointment;

class AppointmentTest {
	Date date = new Date();
	Date futureDate = new Date(date.getTime()*10);
	Date pastDate = new Date(date.getTime()/10);
	Appointment futureAppointment = new Appointment("1",futureDate,"2");
	
	
	
	@Test
	void testAppointmentAssignsCorrectly() {
		assertTrue(futureAppointment.getDate().equals(futureDate));
		assertTrue(futureAppointment.getID().equals("1"));
		assertTrue(futureAppointment.getDescription().equals("2"));
	}
	
	@Test
	void testExceptionsForNull() {
		assertThrows(IllegalArgumentException.class,()-> {
		new Appointment(null,futureDate,"1");
		});
		assertThrows(IllegalArgumentException.class,()-> {
		new Appointment("1",null,"1");
		});
		assertThrows(IllegalArgumentException.class,()-> {
		new Appointment("1",futureDate,null);
		});
	}
	
	@Test
	void testExceptionForLength() {
		assertThrows(IllegalArgumentException.class, ()-> {
			new Appointment("12345678901",futureDate,"1");
		});
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1",futureDate,"123456789012345678901234567890123456789012345678901");
		});
	}
	
	@Test
	void testExceptionForPastDate() {
		assertThrows(IllegalArgumentException.class, ()-> {
			new Appointment("1",pastDate,"1");
		});
	}
}

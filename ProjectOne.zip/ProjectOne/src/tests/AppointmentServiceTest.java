package tests;
import org.junit.jupiter.api.Test;

import classes.Appointment;
import classes.AppointmentService;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

class AppointmentServiceTest {
	AppointmentService as = new AppointmentService();
	Date date = new Date();
	Date futureDate = new Date(date.getTime()*10);
	Appointment appointment = new Appointment("1",futureDate,"2");
	
	@Test
	void testAddAppointments() {
		as.addAppointment(appointment);
		assertThrows(IllegalArgumentException.class, ()-> {
			as.addAppointment(appointment);
		});
	}
	
	@Test
	void testDeleteAppointment() {
		as.addAppointment(appointment);
		as.deleteAppointment("1");
		assertThrows(IllegalArgumentException.class, () -> {
			as.deleteAppointment(appointment.getID());
		});
	}
}
